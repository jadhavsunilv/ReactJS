// firebase config
 // Your web app's Firebase configuration
 export const firebaseConfig = {
  apiKey: "XXXXX",
  authDomain: "XXXXX",
  projectId: "XXXX",
  storageBucket: "XXXXX",
  messagingSenderId: "XXX",
  appId: "XXXXXX"
};